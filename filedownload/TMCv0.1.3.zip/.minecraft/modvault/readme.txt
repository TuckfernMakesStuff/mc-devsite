this is the vault that keeps your mods
put mods as a folder (example: Guns Mod). You could re-use
mods for later or zip it as archive to save storage.
built-in mods doesn't count as installed mods :)